from selenium import webdriver

from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver import Keys

service=Service("./chromedriver.exe")

driver=webdriver.Chrome(service=service)

driver.get("http://www.google.com")
driver.maximize_window()
searchBox=driver.find_element(By.NAME,"q")
searchBox.send_keys("python")
searchBox.send_keys(Keys.ENTER)
driver.find_element(By.CLASS_NAME,"vdQmEd fP1Qef xpd EtOod pkphOe").click()


