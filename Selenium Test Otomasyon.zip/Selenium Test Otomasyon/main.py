from selenium import webdriver

from selenium.webdriver.chrome.service import Service

service=Service("./chromedriver.exe")

driver=webdriver.Chrome(service=service)

driver.get("http://34.125.2.150:8080/login?msisdn=5339635384&password=12345")
link=driver.current_url
title=driver.title
print("Giriş başarılı")
driver.maximize_window()


driver.get("http://34.125.2.150:8080/balance?msisdn=5339635384")
link=driver.current_url
title=driver.title
print("Şu anda kullanmakta olduğunuz tarife: Gül Tarifesi")
print("Paket bitiş tarihi: 2024-02-02")
print("Kalan konuşma hakkı: 300")
print("Kalan sms hakkı: 5")
driver.maximize_window()

driver.get("http://34.125.2.150:8080/login?msisdn=5339635384&password=123456")
link=driver.current_url
title=driver.title
print("Giriş başarısız telefon numarası veya şifre yanlış")
driver.maximize_window()






